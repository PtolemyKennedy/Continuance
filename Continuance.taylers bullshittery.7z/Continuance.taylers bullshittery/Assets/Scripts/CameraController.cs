﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour {

    public GameObject player;

    public Vector3 magicPoint;
    public float xMarginL, xMarginR, yMarginT, yMarginB;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update ()
    {
        //Vector3 playerPos = Camera.main.WorldToViewportPoint(player.transform.position);

        Vector3 playerPos = player.transform.position;


        //transform.position = Camera.main.ViewportToWorldPoint(playerPos);
    }
}
