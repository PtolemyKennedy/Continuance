﻿using UnityEngine;
using System.Collections;

public class PlayerEventHandler : MonoBehaviour {

    public string KeyAccelerate;
    public string KeyReverse;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (Input.GetKey("q"))
        {
            EventManager.TriggerEvent("Accelerate");
        }
        else if (Input.GetKey("e"))
        {
            EventManager.TriggerEvent("Reverse");
        }
        else
        {
            EventManager.TriggerEvent("Normalise");
        }
	}
}
