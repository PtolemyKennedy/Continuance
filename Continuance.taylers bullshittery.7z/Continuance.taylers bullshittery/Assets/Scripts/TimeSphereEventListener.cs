﻿using UnityEngine;
using UnityEngine.Events;
using System.Collections;

public class TimeSphereEventListener : MonoBehaviour
{

    private UnityAction AccelerateListener;
    private UnityAction ReverseListener;
    private UnityAction DeactivateListener;
    public Vector3 MinimumSize;
    public Vector3 MaximumSize;
    

    void Awake()
    {
        AccelerateListener = new UnityAction(Accelerate);
        ReverseListener = new UnityAction(Reverse);
        DeactivateListener = new UnityAction(Deactivate);
    }

    void OnEnable()
    {
        EventManager.StartListening("Accelerate", AccelerateListener);
        EventManager.StartListening("Reverse", ReverseListener);
        EventManager.StartListening("Deactivate", DeactivateListener);

    }

    void OnDisable()
    {
        EventManager.StopListening("Accelerate", AccelerateListener);
        EventManager.StopListening("Reverse", ReverseListener);
        EventManager.StopListening("Deactivate", DeactivateListener);

    }

    void Accelerate()
    {
        tag = "TimeSphere-Accelerate";
        StartCoroutine(Grow());
    }

    void Reverse()
    {
        tag = "TimeSphere-Reverse";
        StartCoroutine(Grow());
    }

    void Deactivate()
    {
        tag = "TimeSphere-Normal";
        StartCoroutine(Shrink());
    }

    IEnumerator Grow()
    {
        while(transform.localScale.x < MaximumSize.x)
        {
            transform.localScale += new Vector3(0.1f, 0.1f, 0.1f);
            yield return new WaitForEndOfFrame();
        }
        transform.localScale = MaximumSize;
    }

    IEnumerator Shrink()
    {
        while (transform.localScale.x > MinimumSize.x)
        {
            transform.localScale -= new Vector3(0.1f, 0.1f, 0.1f);
            yield return new WaitForEndOfFrame();
        }
        transform.localScale = MinimumSize;
    }

    void OnTriggerEnter(Collider col)
    {
        Debug.Log("#Triggered by " + col.tag);
        if (col.tag.Contains("Fixable") && tag.Contains("TimeSphere-Reverse"))
        {
            Debug.Log("it is a fixable platform");
            col.GetComponent<Platform>().Fix();
        }
        if (col.tag.Contains("Destroyable") && tag.Contains("TimeSphere-Accelerate"))
        {
            Debug.Log("it is a destroyable platform");
            col.GetComponent<Platform>().Destroy();
        }
    }
}