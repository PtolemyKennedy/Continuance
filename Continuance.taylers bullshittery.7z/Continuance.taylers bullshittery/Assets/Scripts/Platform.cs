﻿using UnityEngine;
using System.Collections;

public class Platform : MonoBehaviour
{
    public BoxCollider platformCollider;
    public Renderer platformRenderer;
    // Use this for initialization
    void Start ()
    {
        if (tag.Contains("Fixable"))
        {
            Destroy();
        } 
        else if(tag.Contains("Destroyable"))
        {
            Fix();
        }
    }

    public void Fix()
    {
        //change platform to be not walkable on 
        platformCollider.enabled = true;
        //change visuals
        platformRenderer.material.color = Color.green;
    }

    public void Destroy()
    {
        platformCollider.enabled = false;
        platformRenderer.material.color = Color.red;
    }

}
